import { useEffect } from 'react'

export default function PopUpThongTin({ tieuDe, moTa, onDong, children }) {
  useEffect(() => {
    const xuLyPhim = (sukKien) => {
      if (sukKien.key === 'Escape') onDong()
    }
    document.addEventListener('keydown', xuLyPhim)
    document.body.style.overflow = 'hidden'
    return () => {
      document.removeEventListener('keydown', xuLyPhim)
      document.body.style.overflow = ''
    }
  }, [onDong])

  return (
    <div className="lop-phu-popup" onClick={onDong}>
      <div
        className="hop-popup"
        role="dialog"
        aria-modal="true"
        onClick={(sukKien) => sukKien.stopPropagation()}
      >
        <button className="hop-popup__nut-dong" onClick={onDong} aria-label="Đóng">
          ✕
        </button>
        <div className="tieu-de-khu" style={{ marginBottom: 24 }}>
          <div>
            <h2>{tieuDe}</h2>
            {moTa && <p>{moTa}</p>}
          </div>
        </div>
        {children}
      </div>
    </div>
  )
}
