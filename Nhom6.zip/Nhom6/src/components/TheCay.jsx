import { Link } from 'react-router-dom'
import { dinhDangTien } from '../tienIch/dinhDang.js'
import { dungGioHang } from '../ngCanhGioHang.jsx'

export default function TheCay({ cay }) {
  const { themVaoGio } = dungGioHang()
  const phanTramGiam = cay.giaGoc
    ? Math.round((1 - cay.gia / cay.giaGoc) * 100)
    : null

  return (
    <div className="the-cay">
      <Link to={`/san-pham/${cay.id}`}>
        <div
          className="the-cay__anh"
          style={
            cay.anhUrl
              ? { backgroundImage: `url(${cay.anhUrl})`, backgroundSize: 'cover', backgroundPosition: 'center' }
              : { background: `linear-gradient(155deg, ${cay.anhMauSac}, #10321d)` }
          }
        >
          {!cay.anhUrl && cay.ten}
          {phanTramGiam && (
            <span className="the-cay__giam-gia">-{phanTramGiam}%</span>
          )}
        </div>
      </Link>

      <div className="the-cay__noi-dung">
        <div className="the-cay__danh-gia">
          ⭐ {cay.danhGia} · {cay.soDanhGia} đánh giá
        </div>

        <Link to={`/san-pham/${cay.id}`}>
          <h3 className="the-cay__ten">{cay.ten}</h3>
        </Link>
        <p className="the-cay__ten-khoa-hoc">{cay.tenKhoaHoc}</p>

        <div className="the-cay__thong-tin">
          <span>{cay.kichThuoc}</span>
        </div>

        <div className="the-cay__gia-va-nut">
          <div className="the-cay__gia">
            <span className="gia-hien-tai">{dinhDangTien(cay.gia)}</span>
            {cay.giaGoc && <span className="gia-goc">{dinhDangTien(cay.giaGoc)}</span>}
          </div>
          <button
            className="nut-them-vao-gio"
            onClick={() => themVaoGio(cay, 1)}
          >
            Thêm vào giỏ
          </button>
        </div>
      </div>
    </div>
  )
}
