export default function ChanTrang() {
  return (
    <footer className="chan-trang">
      <div className="khung">
        <div className="luoi-chan-trang">
          <div>
            <div className="chan-trang__logo">🌿 Xanh SM</div>
            <p className="chan-trang__mo-ta">
              Mang thiên nhiên vào từng góc nhà Việt — cây khỏe, giao nhanh,
              chăm sóc tận tâm từ vườn ươm đến tận cửa nhà bạn.
            </p>
          </div>

          <div className="chan-trang__cot">
            <h4>Cửa hàng</h4>
            <ul>
              <li>Cây dễ sống</li>
              <li>Cây phong thủy</li>
              <li>Cây để bàn</li>
              <li>Cây ngoài trời</li>
            </ul>
          </div>

          <div className="chan-trang__cot">
            <h4>Hỗ trợ</h4>
            <ul>
              <li>Hướng dẫn chăm sóc</li>
              <li>Chính sách đổi trả</li>
              <li>Vận chuyển & giao hàng</li>
              <li>Câu hỏi thường gặp</li>
            </ul>
          </div>
        </div>

        <div className="chan-trang__duoi">
          <span>© 2026 Xanh SM. All Rights Reserved.</span>
          <span>Sản phẩm thuộc hệ sinh thái Xanh SM</span>
        </div>
      </div>
    </footer>
  )
}
