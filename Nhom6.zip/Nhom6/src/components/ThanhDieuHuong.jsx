import { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { dungGioHang } from '../ngCanhGioHang.jsx'
import { dungNguoiDung } from '../ngCanhNguoiDung.jsx'
import PopUpThongTin from './PopUpThongTin.jsx'

const camKet = [
  {
    so: '01',
    tieuDe: 'Cây khỏe, đúng mô tả',
    moTa: 'Mỗi cây được tuyển chọn từ vườn ươm đạt chuẩn, kiểm tra kỹ trước khi đóng gói.',
  },
  {
    so: '02',
    tieuDe: 'Giao nhanh trong ngày',
    moTa: 'Đội xe điện Xanh SM giao cây tận nơi trong nội thành, giữ cây tươi nguyên vẹn.',
  },
  {
    so: '03',
    tieuDe: 'Đổi trả trong 7 ngày',
    moTa: 'Cây yếu hoặc hư hại khi nhận được đổi mới miễn phí, không cần lý do phức tạp.',
  },
  {
    so: '04',
    tieuDe: 'Tư vấn chăm sóc trọn đời',
    moTa: 'Đội ngũ làm vườn hỗ trợ bạn qua điện thoại bất cứ khi nào cây gặp vấn đề.',
  },
]

export default function ThanhDieuHuong() {
  const { tongSoLuong } = dungGioHang()
  const { daDangNhap, laAdmin, nguoiDungHienTai, dangXuat } = dungNguoiDung()
  const dieuHuong = useNavigate()
  const [popupDangMo, datPopupDangMo] = useState(null)

  const xuLyDangXuat = () => {
    dangXuat()
    dieuHuong('/')
  }

  return (
    <header className="thanh-dieu-huong">
      <div className="khung thanh-dieu-huong__noi-dung">
        <Link to="/" className="logo">
          <span className="logo__bieu-tuong">🌿</span>
          Xanh SM
        </Link>

        <nav>
          <ul className="thuc-don-chinh">
            <li><Link to="/">Trang chủ</Link></li>
            <li><Link to="/san-pham">Sản phẩm</Link></li>
            <li>
              <button className="nut-thuc-don" onClick={() => datPopupDangMo('cam-ket')}>
                Vì sao chọn chúng tôi
              </button>
            </li>
            <li>
              <button className="nut-thuc-don" onClick={() => datPopupDangMo('lien-he')}>
                Liên hệ
              </button>
            </li>
            {daDangNhap && !laAdmin && <li><Link to="/don-hang">Đơn hàng của tôi</Link></li>}
            {laAdmin && <li><Link to="/quan-tri">Quản trị cây</Link></li>}
          </ul>
        </nav>

        <div className="thanh-dieu-huong__phai">
          {daDangNhap ? (
            <div className="hop-tai-khoan">
              <span className="hop-tai-khoan__ten">
                Chào, {nguoiDungHienTai?.hoTen?.split(' ').slice(-1)[0]}
              </span>
              <button className="nut-phu-sang" onClick={xuLyDangXuat}>
                Đăng xuất
              </button>
            </div>
          ) : (
            <Link to="/dang-nhap" className="nut-phu-sang">
              Đăng nhập
            </Link>
          )}

          {laAdmin ? (
            <Link to="/quan-tri/don-hang" className="nut-gio-hang">
              📋 Danh sách đơn hàng
            </Link>
          ) : (
            <Link to="/gio-hang" className="nut-gio-hang">
              🛒 Giỏ hàng {tongSoLuong > 0 && `(${tongSoLuong})`}
            </Link>
          )}
        </div>
      </div>

      {popupDangMo === 'cam-ket' && (
        <PopUpThongTin
          tieuDe="Vì sao chọn Xanh SM"
          moTa="Cam kết chất lượng từ vườn ươm đến tận nhà bạn"
          onDong={() => datPopupDangMo(null)}
        >
          <div className="luoi-cam-ket">
            {camKet.map((muc) => (
              <div className="the-cam-ket" key={muc.so}>
                <div className="the-cam-ket__so">{muc.so}</div>
                <h3 className="the-cam-ket__tieu-de">{muc.tieuDe}</h3>
                <p className="the-cam-ket__mo-ta">{muc.moTa}</p>
              </div>
            ))}
          </div>
        </PopUpThongTin>
      )}

      {popupDangMo === 'lien-he' && (
        <PopUpThongTin
          tieuDe="Liên hệ với chúng tôi"
          moTa="Đội ngũ Xanh SM luôn sẵn sàng hỗ trợ bạn"
          onDong={() => datPopupDangMo(null)}
        >
          <ul className="danh-sach-lien-he">
            <li>📞 1900 1900</li>
            <li>✉️ hungthinh@xanhsm.vn</li>
            <li>📍 120 Lương Châu - Tiên Dược - Sóc Sơn - Hà Nội</li>
          </ul>
        </PopUpThongTin>
      )}
    </header>
  )
}
