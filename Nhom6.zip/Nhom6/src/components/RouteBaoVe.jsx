import { Navigate, useLocation } from 'react-router-dom'
import { dungNguoiDung } from '../ngCanhNguoiDung.jsx'

export default function RouteBaoVe({ children, yeuCauAdmin = false }) {
  const { daDangNhap, laAdmin, dangTai } = dungNguoiDung()
  const viTri = useLocation()

  if (dangTai) return null

  if (!daDangNhap) {
    return <Navigate to="/dang-nhap" state={{ tuTrang: viTri.pathname }} replace />
  }

  if (yeuCauAdmin && !laAdmin) {
    return <Navigate to="/" replace />
  }

  return children
}
