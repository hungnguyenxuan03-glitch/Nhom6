import { createContext, useContext, useEffect, useState } from 'react'
import { danhSachCay as danhSachCayGoc, danhMucCay } from './du-lieu/danhSachCay.js'

const NguCanhSanPham = createContext(null)
const KHOA_DANH_SACH_CAY = 'xanhsm_danh_sach_cay'

function docDanhSachCay() {
  try {
    const du_lieu = localStorage.getItem(KHOA_DANH_SACH_CAY)
    if (!du_lieu) {
      localStorage.setItem(KHOA_DANH_SACH_CAY, JSON.stringify(danhSachCayGoc))
      return danhSachCayGoc
    }
    return JSON.parse(du_lieu)
  } catch {
    return danhSachCayGoc
  }
}

function ghiDanhSachCay(danhSach) {
  localStorage.setItem(KHOA_DANH_SACH_CAY, JSON.stringify(danhSach))
}

export function NhaCungCapSanPham({ children }) {
  const [danhSachCay, datDanhSachCay] = useState([])

  useEffect(() => {
    datDanhSachCay(docDanhSachCay())
  }, [])

  const themCay = (cayMoi) => {
    const idMoi = danhSachCay.length > 0 ? Math.max(...danhSachCay.map((c) => c.id)) + 1 : 1
    const cayHoanChinh = { ...cayMoi, id: idMoi }
    const danhSachMoi = [...danhSachCay, cayHoanChinh]
    datDanhSachCay(danhSachMoi)
    ghiDanhSachCay(danhSachMoi)
    return cayHoanChinh
  }

  const suaCay = (id, duLieuCapNhat) => {
    const danhSachMoi = danhSachCay.map((c) =>
      c.id === id ? { ...c, ...duLieuCapNhat, id } : c
    )
    datDanhSachCay(danhSachMoi)
    ghiDanhSachCay(danhSachMoi)
  }

  const xoaCay = (id) => {
    const danhSachMoi = danhSachCay.filter((c) => c.id !== id)
    datDanhSachCay(danhSachMoi)
    ghiDanhSachCay(danhSachMoi)
  }

  const layCayTheoId = (id) => danhSachCay.find((c) => c.id === Number(id))

  const datLaiVeMacDinh = () => {
    datDanhSachCay(danhSachCayGoc)
    ghiDanhSachCay(danhSachCayGoc)
  }

  const giaTri = {
    danhSachCay,
    danhMucCay,
    themCay,
    suaCay,
    xoaCay,
    layCayTheoId,
    datLaiVeMacDinh,
  }

  return (
    <NguCanhSanPham.Provider value={giaTri}>
      {children}
    </NguCanhSanPham.Provider>
  )
}

export function dungSanPham() {
  const giaTri = useContext(NguCanhSanPham)
  if (!giaTri) {
    throw new Error('dungSanPham phải được dùng bên trong NhaCungCapSanPham')
  }
  return giaTri
}
