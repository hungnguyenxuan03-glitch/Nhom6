import { createContext, useContext, useEffect, useState } from 'react'

const NguCanhNguoiDung = createContext(null)

const KHOA_DANH_SACH_NGUOI_DUNG = 'xanhsm_danh_sach_nguoi_dung'
const KHOA_NGUOI_DUNG_HIEN_TAI = 'xanhsm_nguoi_dung_hien_tai'

// Tài khoản quản trị mặc định — đổi mật khẩu này trước khi triển khai thật
const TAI_KHOAN_ADMIN_MAC_DINH = {
  hoTen: 'Quản trị viên',
  tenDangNhap: 'admin',
  matKhau: 'admin123',
  vaiTro: 'admin',
}

function docDanhSachNguoiDung() {
  try {
    const du_lieu = localStorage.getItem(KHOA_DANH_SACH_NGUOI_DUNG)
    if (!du_lieu) {
      const banDau = [TAI_KHOAN_ADMIN_MAC_DINH]
      localStorage.setItem(KHOA_DANH_SACH_NGUOI_DUNG, JSON.stringify(banDau))
      return banDau
    }
    const danhSach = JSON.parse(du_lieu)
    // Dữ liệu cũ (trước khi đổi từ email sang tên đăng nhập) sẽ không có trường tenDangNhap — làm sạch lại
    const hopLe = Array.isArray(danhSach) && danhSach.every((nd) => typeof nd.tenDangNhap === 'string')
    if (!hopLe) {
      const banDau = [TAI_KHOAN_ADMIN_MAC_DINH]
      localStorage.setItem(KHOA_DANH_SACH_NGUOI_DUNG, JSON.stringify(banDau))
      localStorage.removeItem(KHOA_NGUOI_DUNG_HIEN_TAI)
      return banDau
    }
    return danhSach
  } catch {
    return [TAI_KHOAN_ADMIN_MAC_DINH]
  }
}

function ghiDanhSachNguoiDung(danhSach) {
  localStorage.setItem(KHOA_DANH_SACH_NGUOI_DUNG, JSON.stringify(danhSach))
}

export function NhaCungCapNguoiDung({ children }) {
  const [nguoiDungHienTai, datNguoiDungHienTai] = useState(null)
  const [dangTai, datDangTai] = useState(true)

  useEffect(() => {
    try {
      const du_lieu = localStorage.getItem(KHOA_NGUOI_DUNG_HIEN_TAI)
      if (du_lieu) datNguoiDungHienTai(JSON.parse(du_lieu))
    } catch {
      // bỏ qua nếu dữ liệu hỏng
    } finally {
      datDangTai(false)
    }
  }, [])

  const dangNhap = (tenDangNhap, matKhau) => {
    const danhSach = docDanhSachNguoiDung()
    const nguoiDung = danhSach.find(
      (nd) => nd.tenDangNhap.toLowerCase() === tenDangNhap.toLowerCase() && nd.matKhau === matKhau
    )
    if (!nguoiDung) {
      return { thanhCong: false, thongBao: 'Tên đăng nhập hoặc mật khẩu không đúng.' }
    }
    const { matKhau: _bo, ...nguoiDungAnToan } = nguoiDung
    datNguoiDungHienTai(nguoiDungAnToan)
    localStorage.setItem(KHOA_NGUOI_DUNG_HIEN_TAI, JSON.stringify(nguoiDungAnToan))
    return { thanhCong: true }
  }

  const dangKy = ({ hoTen, tenDangNhap, matKhau }) => {
    const danhSach = docDanhSachNguoiDung()
    const trung = danhSach.some((nd) => nd.tenDangNhap.toLowerCase() === tenDangNhap.toLowerCase())
    if (trung) {
      return { thanhCong: false, thongBao: 'Tên đăng nhập này đã tồn tại.' }
    }
    const nguoiDungMoi = { hoTen, tenDangNhap, matKhau, vaiTro: 'khach' }
    const danhSachMoi = [...danhSach, nguoiDungMoi]
    ghiDanhSachNguoiDung(danhSachMoi)

    const { matKhau: _bo, ...nguoiDungAnToan } = nguoiDungMoi
    datNguoiDungHienTai(nguoiDungAnToan)
    localStorage.setItem(KHOA_NGUOI_DUNG_HIEN_TAI, JSON.stringify(nguoiDungAnToan))
    return { thanhCong: true }
  }

  const dangXuat = () => {
    datNguoiDungHienTai(null)
    localStorage.removeItem(KHOA_NGUOI_DUNG_HIEN_TAI)
  }

  const giaTri = {
    nguoiDungHienTai,
    dangTai,
    daDangNhap: !!nguoiDungHienTai,
    laAdmin: nguoiDungHienTai?.vaiTro === 'admin',
    dangNhap,
    dangKy,
    dangXuat,
  }

  return (
    <NguCanhNguoiDung.Provider value={giaTri}>
      {children}
    </NguCanhNguoiDung.Provider>
  )
}

export function dungNguoiDung() {
  const giaTri = useContext(NguCanhNguoiDung)
  if (!giaTri) {
    throw new Error('dungNguoiDung phải được dùng bên trong NhaCungCapNguoiDung')
  }
  return giaTri
}
