import { createContext, useContext, useMemo, useState } from 'react'

const NguCanhGioHang = createContext(null)

export function NhaCungCapGioHang({ children }) {
  const [cacMuc, setCacMuc] = useState([])

  const themVaoGio = (cay, soLuong = 1) => {
    setCacMuc((truoc) => {
      const daCo = truoc.find((m) => m.cay.id === cay.id)
      if (daCo) {
        return truoc.map((m) =>
          m.cay.id === cay.id ? { ...m, soLuong: m.soLuong + soLuong } : m
        )
      }
      return [...truoc, { cay, soLuong }]
    })
  }

  const capNhatSoLuong = (idCay, soLuong) => {
    if (soLuong <= 0) {
      xoaKhoiGio(idCay)
      return
    }
    setCacMuc((truoc) =>
      truoc.map((m) => (m.cay.id === idCay ? { ...m, soLuong } : m))
    )
  }

  const xoaKhoiGio = (idCay) => {
    setCacMuc((truoc) => truoc.filter((m) => m.cay.id !== idCay))
  }

  const lamRongGio = () => {
    setCacMuc([])
  }

  const tongSoLuong = useMemo(
    () => cacMuc.reduce((tong, m) => tong + m.soLuong, 0),
    [cacMuc]
  )

  const tongTien = useMemo(
    () => cacMuc.reduce((tong, m) => tong + m.soLuong * m.cay.gia, 0),
    [cacMuc]
  )

  const giaTri = {
    cacMuc,
    themVaoGio,
    capNhatSoLuong,
    xoaKhoiGio,
    lamRongGio,
    tongSoLuong,
    tongTien,
  }

  return (
    <NguCanhGioHang.Provider value={giaTri}>
      {children}
    </NguCanhGioHang.Provider>
  )
}

export function dungGioHang() {
  const giaTri = useContext(NguCanhGioHang)
  if (!giaTri) {
    throw new Error('dungGioHang phải được dùng bên trong NhaCungCapGioHang')
  }
  return giaTri
}
