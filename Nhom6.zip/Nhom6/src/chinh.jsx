import React from 'react'
import ReactDOM from 'react-dom/client'
import { BrowserRouter } from 'react-router-dom'
import UngDung from './UngDung.jsx'
import './kieu-dang/toanCuc.css'

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <BrowserRouter>
      <UngDung />
    </BrowserRouter>
  </React.StrictMode>
)
