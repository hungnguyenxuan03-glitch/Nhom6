export function dinhDangTien(soTien) {
  return soTien.toLocaleString('vi-VN') + '₫'
}
