import { createContext, useContext, useEffect, useState } from 'react'

const NguCanhDonHang = createContext(null)
const KHOA_DON_HANG = 'xanhsm_danh_sach_don_hang'

export const CAC_TRANG_THAI = [
  { id: 'dang-giao', ten: 'Đang giao' },
  { id: 'da-giao', ten: 'Đã giao' },
  { id: 'da-huy', ten: 'Đã hủy' },
]

function docDonHang() {
  try {
    const du_lieu = localStorage.getItem(KHOA_DON_HANG)
    return du_lieu ? JSON.parse(du_lieu) : []
  } catch {
    return []
  }
}

function ghiDonHang(danhSach) {
  localStorage.setItem(KHOA_DON_HANG, JSON.stringify(danhSach))
}

export function NhaCungCapDonHang({ children }) {
  const [danhSachDonHang, datDanhSachDonHang] = useState([])

  useEffect(() => {
    datDanhSachDonHang(docDonHang())
  }, [])

  const taoDonHang = ({ tenDangNhapNguoiDung, hoTenNguoiDung, cacMuc, tongTien, phiVanChuyen, tongCong }) => {
    const idMoi = danhSachDonHang.length > 0 ? Math.max(...danhSachDonHang.map((d) => d.id)) + 1 : 1
    const donHangMoi = {
      id: idMoi,
      maDon: `XSM${String(idMoi).padStart(5, '0')}`,
      tenDangNhapNguoiDung,
      hoTenNguoiDung,
      ngayDat: new Date().toISOString(),
      cacMuc,
      tongTien,
      phiVanChuyen,
      tongCong,
      trangThai: 'dang-giao',
    }
    const danhSachMoi = [donHangMoi, ...danhSachDonHang]
    datDanhSachDonHang(danhSachMoi)
    ghiDonHang(danhSachMoi)
    return donHangMoi
  }

  const capNhatTrangThai = (idDonHang, trangThaiMoi) => {
    const danhSachMoi = danhSachDonHang.map((d) =>
      d.id === idDonHang ? { ...d, trangThai: trangThaiMoi } : d
    )
    datDanhSachDonHang(danhSachMoi)
    ghiDonHang(danhSachMoi)
  }

  const layDonHangTheoNguoiDung = (tenDangNhap) =>
    danhSachDonHang.filter((d) => d.tenDangNhapNguoiDung === tenDangNhap)

  const giaTri = {
    danhSachDonHang,
    taoDonHang,
    capNhatTrangThai,
    layDonHangTheoNguoiDung,
  }

  return (
    <NguCanhDonHang.Provider value={giaTri}>
      {children}
    </NguCanhDonHang.Provider>
  )
}

export function dungDonHang() {
  const giaTri = useContext(NguCanhDonHang)
  if (!giaTri) {
    throw new Error('dungDonHang phải được dùng bên trong NhaCungCapDonHang')
  }
  return giaTri
}
