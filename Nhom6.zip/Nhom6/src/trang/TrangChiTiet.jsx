import { useState } from 'react'
import { Link, useNavigate, useParams } from 'react-router-dom'
import { dungSanPham } from '../ngCanhSanPham.jsx'
import { dinhDangTien } from '../tienIch/dinhDang.js'
import { dungGioHang } from '../ngCanhGioHang.jsx'

export default function TrangChiTiet() {
  const { id } = useParams()
  const dieuHuong = useNavigate()
  const { layCayTheoId } = dungSanPham()
  const { themVaoGio } = dungGioHang()
  const [soLuong, datSoLuong] = useState(1)

  const cay = layCayTheoId(id)

  if (!cay) {
    return (
      <div className="gio-hang-trong khung">
        <h2>Không tìm thấy cây này</h2>
        <p>Có thể sản phẩm đã ngừng kinh doanh.</p>
        <Link to="/san-pham" className="nut-chinh" style={{ display: 'inline-block', marginTop: 16 }}>
          Quay lại danh sách cây
        </Link>
      </div>
    )
  }

  const xuLyThemVaoGio = () => {
    themVaoGio(cay, soLuong)
    dieuHuong('/gio-hang')
  }

  return (
    <div className="trang-chi-tiet khung">
      <p className="duong-dan">
        <Link to="/">Trang chủ</Link> / <Link to="/san-pham">Cây cảnh</Link> / {cay.ten}
      </p>

      <div className="luoi-chi-tiet">
        <div
          className="chi-tiet__anh"
          style={
            cay.anhUrl
              ? { backgroundImage: `url(${cay.anhUrl})`, backgroundSize: 'cover', backgroundPosition: 'center' }
              : { background: `linear-gradient(155deg, ${cay.anhMauSac}, #10321d)` }
          }
        >
          {!cay.anhUrl && cay.ten}
        </div>

        <div>
          <h1 className="chi-tiet__ten">{cay.ten}</h1>
          <p className="chi-tiet__ten-khoa-hoc">{cay.tenKhoaHoc}</p>

          <div className="the-cay__danh-gia" style={{ marginBottom: 16 }}>
            ⭐ {cay.danhGia} · {cay.soDanhGia} đánh giá
          </div>

          <div className="chi-tiet__gia">
            <span className="gia-hien-tai">{dinhDangTien(cay.gia)}</span>
            {cay.giaGoc && <span className="gia-goc">{dinhDangTien(cay.giaGoc)}</span>}
          </div>

          <p className="chi-tiet__mo-ta">{cay.moTa}</p>

          <div className="bang-thong-so">
            <div>
              <div className="thong-so__nhan">Kích thước</div>
              <div className="thong-so__gia-tri">{cay.kichThuoc}</div>
            </div>
            <div>
              <div className="thong-so__nhan">Ánh sáng phù hợp</div>
              <div className="thong-so__gia-tri">{cay.anhSang}</div>
            </div>
            <div>
              <div className="thong-so__nhan">Tần suất tưới nước</div>
              <div className="thong-so__gia-tri">{cay.tuoiNuoc}</div>
            </div>
            <div>
              <div className="thong-so__nhan">Danh mục</div>
              <div className="thong-so__gia-tri">Cây cảnh trong nhà</div>
            </div>
          </div>

          <div className="bo-dieu-khien-so-luong">
            <button className="nut-so-luong" onClick={() => datSoLuong(Math.max(1, soLuong - 1))}>−</button>
            <span style={{ fontSize: 16, fontWeight: 600 }}>{soLuong}</span>
            <button className="nut-so-luong" onClick={() => datSoLuong(soLuong + 1)}>+</button>
          </div>

          <div style={{ display: 'flex', gap: 12 }}>
            <button className="nut-chinh" onClick={xuLyThemVaoGio}>
              Thêm vào giỏ — {dinhDangTien(cay.gia * soLuong)}
            </button>
          </div>
        </div>
      </div>
    </div>
  )
}
