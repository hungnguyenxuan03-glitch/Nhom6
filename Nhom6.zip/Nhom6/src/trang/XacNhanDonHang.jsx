import { Link, useParams } from 'react-router-dom'
import { dungDonHang, CAC_TRANG_THAI } from '../ngCanhDonHang.jsx'
import { dinhDangTien } from '../tienIch/dinhDang.js'

export default function XacNhanDonHang() {
  const { id } = useParams()
  const { danhSachDonHang } = dungDonHang()
  const donHang = danhSachDonHang.find((d) => d.id === Number(id))

  if (!donHang) {
    return (
      <div className="gio-hang-trong khung">
        <h2>Không tìm thấy đơn hàng này</h2>
        <Link to="/" className="nut-chinh" style={{ display: 'inline-block', marginTop: 16 }}>
          Về trang chủ
        </Link>
      </div>
    )
  }

  const tenTrangThai = CAC_TRANG_THAI.find((t) => t.id === donHang.trangThai)?.ten

  return (
    <div className="khung trang-xac-nhan-don">
      <div className="hop-xac-nhan-don">
        <div className="hop-xac-nhan-don__bieu-tuong">🌿</div>
        <h2>Đặt hàng thành công!</h2>
        <p>Cảm ơn bạn đã mua sắm tại Xanh SM.</p>

        <div className="hop-xac-nhan-don__ma">
          Mã đơn hàng: <strong>{donHang.maDon}</strong>
        </div>

        <div className="the-trang-thai">{tenTrangThai}</div>

        <div className="danh-sach-don-thu-nho">
          {donHang.cacMuc.map((muc) => (
            <div className="dong-don-thu-nho" key={muc.cayId}>
              <span>{muc.ten} × {muc.soLuong}</span>
              <span>{dinhDangTien(muc.gia * muc.soLuong)}</span>
            </div>
          ))}
        </div>

        <div className="dong-tom-tat dong-tom-tat--tong">
          <span>Tổng cộng</span>
          <span>{dinhDangTien(donHang.tongCong)}</span>
        </div>

        <div style={{ display: 'flex', gap: 12, marginTop: 24 }}>
          <Link to="/don-hang" className="nut-chinh">Xem đơn hàng của tôi</Link>
          <Link to="/san-pham" className="nut-phu-sang">Tiếp tục mua sắm</Link>
        </div>
      </div>
    </div>
  )
}
