import { useState } from 'react'
import { Link, useLocation, useNavigate } from 'react-router-dom'
import { dungNguoiDung } from '../ngCanhNguoiDung.jsx'

export default function DangNhap() {
  const { dangNhap } = dungNguoiDung()
  const dieuHuong = useNavigate()
  const viTri = useLocation()

  const [tenDangNhap, datTenDangNhap] = useState('')
  const [matKhau, datMatKhau] = useState('')
  const [loi, datLoi] = useState('')

  const xuLySubmit = (sukKien) => {
    sukKien.preventDefault()
    datLoi('')
    const ketQua = dangNhap(tenDangNhap.trim(), matKhau)
    if (!ketQua.thanhCong) {
      datLoi(ketQua.thongBao)
      return
    }
    const duongDanQuayVe = viTri.state?.tuTrang || '/'
    dieuHuong(duongDanQuayVe, { replace: true })
  }

  return (
    <div className="khung trang-xac-thuc">
      <div className="hop-xac-thuc">
        <h2>Đăng nhập</h2>
        <p className="hop-xac-thuc__mo-ta">
          Đăng nhập để đặt cây và theo dõi đơn hàng của bạn.
        </p>

        <form onSubmit={xuLySubmit} className="form-xac-thuc">
          <label>
            Tên đăng nhập
            <input
              type="text"
              value={tenDangNhap}
              onChange={(e) => datTenDangNhap(e.target.value)}
              placeholder="admin"
              autoComplete="username"
              required
            />
          </label>

          <label>
            Mật khẩu
            <input
              type="password"
              value={matKhau}
              onChange={(e) => datMatKhau(e.target.value)}
              placeholder="••••••••"
              autoComplete="current-password"
              required
            />
          </label>

          {loi && <p className="thong-bao-loi">{loi}</p>}

          <button type="submit" className="nut-chinh" style={{ width: '100%' }}>
            Đăng nhập
          </button>
        </form>

        <p className="hop-xac-thuc__chuyen">
          Chưa có tài khoản? <Link to="/dang-ky">Đăng ký ngay</Link>
        </p>

        <div className="hop-xac-thuc__goi-y">
          <strong>Tài khoản quản trị demo:</strong>
          <br />
          Tên đăng nhập: admin — Mật khẩu: admin123
        </div>
      </div>
    </div>
  )
}
