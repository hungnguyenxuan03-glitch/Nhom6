import { Link, useNavigate } from 'react-router-dom'
import { dungGioHang } from '../ngCanhGioHang.jsx'
import { dungNguoiDung } from '../ngCanhNguoiDung.jsx'
import { dungDonHang } from '../ngCanhDonHang.jsx'
import { dinhDangTien } from '../tienIch/dinhDang.js'

const PHI_VAN_CHUYEN = 20000

export default function TrangGioHang() {
  const { cacMuc, capNhatSoLuong, xoaKhoiGio, lamRongGio, tongTien } = dungGioHang()
  const { daDangNhap, nguoiDungHienTai } = dungNguoiDung()
  const { taoDonHang } = dungDonHang()
  const dieuHuong = useNavigate()

  if (cacMuc.length === 0) {
    return (
      <div className="gio-hang-trong khung">
        <h2>Giỏ hàng của bạn đang trống</h2>
        <p>Hãy chọn vài chậu cây xanh để bắt đầu nhé.</p>
        <Link to="/san-pham" className="nut-chinh" style={{ display: 'inline-block', marginTop: 16 }}>
          Khám phá cây cảnh
        </Link>
      </div>
    )
  }

  const tongCong = tongTien + PHI_VAN_CHUYEN

  const xuLyThanhToan = () => {
    if (!daDangNhap) {
      dieuHuong('/dang-nhap', { state: { tuTrang: '/gio-hang' } })
      return
    }

    const donHangMoi = taoDonHang({
      tenDangNhapNguoiDung: nguoiDungHienTai.tenDangNhap,
      hoTenNguoiDung: nguoiDungHienTai.hoTen,
      cacMuc: cacMuc.map(({ cay, soLuong }) => ({
        cayId: cay.id,
        ten: cay.ten,
        anhUrl: cay.anhUrl,
        anhMauSac: cay.anhMauSac,
        gia: cay.gia,
        soLuong,
      })),
      tongTien,
      phiVanChuyen: PHI_VAN_CHUYEN,
      tongCong,
    })

    lamRongGio()
    dieuHuong(`/don-hang/${donHangMoi.id}`)
  }

  return (
    <div className="trang-gio-hang khung">
      <div className="tieu-de-khu">
        <div>
          <h2>Giỏ hàng của bạn</h2>
          <p>{cacMuc.length} loại cây trong giỏ</p>
        </div>
      </div>

      <div className="luoi-chi-tiet" style={{ gridTemplateColumns: '1.6fr 1fr', alignItems: 'start' }}>
        <div>
          {cacMuc.map(({ cay, soLuong }) => (
            <div className="dong-gio-hang" key={cay.id}>
              <div
                className="dong-gio-hang__anh"
                style={
                  cay.anhUrl
                    ? { backgroundImage: `url(${cay.anhUrl})`, backgroundSize: 'cover', backgroundPosition: 'center' }
                    : { background: `linear-gradient(155deg, ${cay.anhMauSac}, #10321d)` }
                }
              />
              <div>
                <h3 className="the-cay__ten" style={{ fontSize: 17 }}>{cay.ten}</h3>
                <p className="the-cay__ten-khoa-hoc" style={{ margin: 0 }}>{cay.tenKhoaHoc}</p>
              </div>

              <div className="bo-dieu-khien-so-luong" style={{ marginBottom: 0 }}>
                <button className="nut-so-luong" onClick={() => capNhatSoLuong(cay.id, soLuong - 1)}>−</button>
                <span style={{ fontWeight: 600 }}>{soLuong}</span>
                <button className="nut-so-luong" onClick={() => capNhatSoLuong(cay.id, soLuong + 1)}>+</button>
              </div>

              <span className="gia-hien-tai">{dinhDangTien(cay.gia * soLuong)}</span>

              <button
                onClick={() => xoaKhoiGio(cay.id)}
                style={{ background: 'none', border: 'none', color: 'var(--chu-nhat)', fontSize: 13 }}
              >
                Xóa
              </button>
            </div>
          ))}
        </div>

        <div className="tom-tat-don-hang">
          <h3 style={{ fontFamily: 'var(--font-tieu-de)', marginTop: 0 }}>Tóm tắt đơn hàng</h3>
          <div className="dong-tom-tat">
            <span>Tạm tính</span>
            <span>{dinhDangTien(tongTien)}</span>
          </div>
          <div className="dong-tom-tat">
            <span>Phí vận chuyển</span>
            <span>{dinhDangTien(PHI_VAN_CHUYEN)}</span>
          </div>
          <div className="dong-tom-tat dong-tom-tat--tong">
            <span>Tổng cộng</span>
            <span>{dinhDangTien(tongCong)}</span>
          </div>
          <button className="nut-chinh" style={{ width: '100%', marginTop: 16 }} onClick={xuLyThanhToan}>
            {daDangNhap ? 'Tiến hành thanh toán' : 'Đăng nhập để thanh toán'}
          </button>
          {!daDangNhap && (
            <p className="thong-bao-nho">
              Bạn cần đăng nhập trước khi đặt hàng.
            </p>
          )}
        </div>
      </div>
    </div>
  )
}
