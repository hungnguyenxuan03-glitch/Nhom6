import { useEffect, useState } from 'react'
import { useNavigate, useParams } from 'react-router-dom'
import { dungSanPham } from '../ngCanhSanPham.jsx'

const CAY_RONG = {
  ten: '',
  tenKhoaHoc: '',
  danhMuc: 'de-song',
  gia: '',
  giaGoc: '',
  anhMauSac: '#2f6b3a',
  anhUrl: '',
  kichThuoc: '',
  anhSang: '',
  tuoiNuoc: '',
  moTa: '',
  noiBat: false,
  danhGia: 5,
  soDanhGia: 0,
}

export default function QuanTriThemSua() {
  const { id } = useParams()
  const dangSua = Boolean(id)
  const dieuHuong = useNavigate()
  const { danhMucCay, themCay, suaCay, layCayTheoId } = dungSanPham()
  const [form, datForm] = useState(CAY_RONG)

  useEffect(() => {
    if (dangSua) {
      const cayHienCo = layCayTheoId(id)
      if (cayHienCo) datForm(cayHienCo)
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id])

  const capNhatTruong = (truong, giaTri) => {
    datForm((truoc) => ({ ...truoc, [truong]: giaTri }))
  }

  const xuLySubmit = (sukKien) => {
    sukKien.preventDefault()

    const duLieu = {
      ...form,
      gia: Number(form.gia) || 0,
      giaGoc: form.giaGoc ? Number(form.giaGoc) : null,
      danhGia: Number(form.danhGia) || 5,
      soDanhGia: Number(form.soDanhGia) || 0,
    }

    if (dangSua) {
      suaCay(Number(id), duLieu)
    } else {
      themCay(duLieu)
    }
    dieuHuong('/quan-tri')
  }

  const cacDanhMucChon = danhMucCay.filter((m) => m.id !== 'tat-ca')

  return (
    <div className="khung trang-quan-tri">
      <div className="tieu-de-khu">
        <div>
          <h2>{dangSua ? 'Sửa cây' : 'Thêm cây mới'}</h2>
          <p>Điền đầy đủ thông tin sản phẩm bên dưới</p>
        </div>
      </div>

      <form onSubmit={xuLySubmit} className="form-quan-tri">
        <div className="form-quan-tri__luoi">
          <label>
            Tên cây
            <input
              type="text"
              value={form.ten}
              onChange={(e) => capNhatTruong('ten', e.target.value)}
              required
            />
          </label>

          <label>
            Tên khoa học
            <input
              type="text"
              value={form.tenKhoaHoc}
              onChange={(e) => capNhatTruong('tenKhoaHoc', e.target.value)}
            />
          </label>

          <label>
            Danh mục
            <select
              value={form.danhMuc}
              onChange={(e) => capNhatTruong('danhMuc', e.target.value)}
            >
              {cacDanhMucChon.map((m) => (
                <option key={m.id} value={m.id}>{m.ten}</option>
              ))}
            </select>
          </label>

          <label>
            Giá bán (₫)
            <input
              type="number"
              value={form.gia}
              onChange={(e) => capNhatTruong('gia', e.target.value)}
              required
              min="0"
            />
          </label>

          <label>
            Giá gốc (₫) — để trống nếu không giảm giá
            <input
              type="number"
              value={form.giaGoc ?? ''}
              onChange={(e) => capNhatTruong('giaGoc', e.target.value)}
              min="0"
            />
          </label>

          <label>
            Đường dẫn ảnh (anhUrl)
            <input
              type="text"
              value={form.anhUrl}
              onChange={(e) => capNhatTruong('anhUrl', e.target.value)}
              placeholder="/images/ten-anh.jpg"
            />
          </label>

          <label>
            Màu nền dự phòng (khi chưa có ảnh)
            <input
              type="color"
              value={form.anhMauSac}
              onChange={(e) => capNhatTruong('anhMauSac', e.target.value)}
            />
          </label>

          <label>
            Kích thước
            <input
              type="text"
              value={form.kichThuoc}
              onChange={(e) => capNhatTruong('kichThuoc', e.target.value)}
              placeholder="Chậu 20cm, cao 40cm"
            />
          </label>

          <label>
            Ánh sáng phù hợp
            <input
              type="text"
              value={form.anhSang}
              onChange={(e) => capNhatTruong('anhSang', e.target.value)}
            />
          </label>

          <label>
            Tần suất tưới nước
            <input
              type="text"
              value={form.tuoiNuoc}
              onChange={(e) => capNhatTruong('tuoiNuoc', e.target.value)}
            />
          </label>

          <label>
            Đánh giá (1-5)
            <input
              type="number"
              step="0.1"
              min="1"
              max="5"
              value={form.danhGia}
              onChange={(e) => capNhatTruong('danhGia', e.target.value)}
            />
          </label>

          <label>
            Số lượt đánh giá
            <input
              type="number"
              min="0"
              value={form.soDanhGia}
              onChange={(e) => capNhatTruong('soDanhGia', e.target.value)}
            />
          </label>

          <label className="form-quan-tri__checkbox">
            <input
              type="checkbox"
              checked={form.noiBat}
              onChange={(e) => capNhatTruong('noiBat', e.target.checked)}
            />
            Sản phẩm nổi bật (hiện ở trang chủ)
          </label>
        </div>

        <label>
          Mô tả
          <textarea
            value={form.moTa}
            onChange={(e) => capNhatTruong('moTa', e.target.value)}
            rows={4}
          />
        </label>

        <div style={{ display: 'flex', gap: 12, marginTop: 8 }}>
          <button type="submit" className="nut-chinh">
            {dangSua ? 'Lưu thay đổi' : 'Thêm cây'}
          </button>
          <button
            type="button"
            className="nut-phu-sang"
            onClick={() => dieuHuong('/quan-tri')}
          >
            Hủy
          </button>
        </div>
      </form>
    </div>
  )
}
