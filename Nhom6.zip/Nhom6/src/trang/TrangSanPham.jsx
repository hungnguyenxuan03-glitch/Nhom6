import { useMemo, useState } from 'react'
import { dungSanPham } from '../ngCanhSanPham.jsx'
import TheCay from '../components/TheCay.jsx'

export default function TrangSanPham() {
  const { danhSachCay, danhMucCay } = dungSanPham()
  const [danhMucDangChon, datDanhMucDangChon] = useState('tat-ca')
  const [tuKhoa, datTuKhoa] = useState('')

  const cayHienThi = useMemo(() => {
    return danhSachCay.filter((cay) => {
      const khopDanhMuc = danhMucDangChon === 'tat-ca' || cay.danhMuc === danhMucDangChon
      const khopTuKhoa = cay.ten.toLowerCase().includes(tuKhoa.toLowerCase())
      return khopDanhMuc && khopTuKhoa
    })
  }, [danhMucDangChon, tuKhoa, danhSachCay])

  return (
    <section className="khu-danh-muc khung" style={{ paddingTop: 48 }}>
      <div className="tieu-de-khu">
        <div>
          <h2>Toàn bộ cây cảnh</h2>
          <p>{cayHienThi.length} sản phẩm đang có sẵn</p>
        </div>
        <input
          type="text"
          placeholder="Tìm tên cây..."
          value={tuKhoa}
          onChange={(sukKien) => datTuKhoa(sukKien.target.value)}
          style={{
            padding: '10px 16px',
            borderRadius: 999,
            border: '1px solid var(--vien)',
            fontSize: 14,
            width: 220,
          }}
        />
      </div>

      <div className="hang-danh-muc">
        {danhMucCay.map((muc) => (
          <button
            key={muc.id}
            className={`nut-danh-muc ${danhMucDangChon === muc.id ? 'nut-danh-muc--dang-chon' : ''}`}
            onClick={() => datDanhMucDangChon(muc.id)}
          >
            {muc.ten}
          </button>
        ))}
      </div>

      {cayHienThi.length > 0 ? (
        <div className="luoi-san-pham">
          {cayHienThi.map((cay) => (
            <TheCay key={cay.id} cay={cay} />
          ))}
        </div>
      ) : (
        <div className="gio-hang-trong">
          <h2>Không tìm thấy cây phù hợp</h2>
          <p>Thử đổi từ khóa hoặc chọn danh mục khác nhé.</p>
        </div>
      )}
    </section>
  )
}
