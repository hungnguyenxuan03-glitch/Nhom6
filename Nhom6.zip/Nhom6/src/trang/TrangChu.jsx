import { useMemo, useState } from 'react'
import { dungSanPham } from '../ngCanhSanPham.jsx'
import TheCay from '../components/TheCay.jsx'
import PopUpThongTin from '../components/PopUpThongTin.jsx'

const camKet = [
  {
    so: '01',
    tieuDe: 'Cây khỏe, đúng mô tả',
    moTa: 'Mỗi cây được tuyển chọn từ vườn ươm đạt chuẩn, kiểm tra kỹ trước khi đóng gói.',
  },
  {
    so: '02',
    tieuDe: 'Giao nhanh trong ngày',
    moTa: 'Đội xe điện Xanh SM giao cây tận nơi trong nội thành, giữ cây tươi nguyên vẹn.',
  },
  {
    so: '03',
    tieuDe: 'Đổi trả trong 7 ngày',
    moTa: 'Cây yếu hoặc hư hại khi nhận được đổi mới miễn phí, không cần lý do phức tạp.',
  },
  {
    so: '04',
    tieuDe: 'Tư vấn chăm sóc trọn đời',
    moTa: 'Đội ngũ làm vườn hỗ trợ bạn qua điện thoại bất cứ khi nào cây gặp vấn đề.',
  },
]

export default function TrangChu() {
  const { danhSachCay, danhMucCay } = dungSanPham()
  const [danhMucDangChon, datDanhMucDangChon] = useState('tat-ca')
  const [hienCamKet, datHienCamKet] = useState(false)

  const cayHienThi = useMemo(() => {
    if (danhMucDangChon === 'tat-ca') return danhSachCay
    return danhSachCay.filter((cay) => cay.danhMuc === danhMucDangChon)
  }, [danhMucDangChon, danhSachCay])

  return (
    <>
      <section className="khu-gioi-thieu">
        <div className="khung khu-gioi-thieu__luoi">
          <div>
            <span className="khu-gioi-thieu__nhan">🌱 Vườn ươm chuẩn VietGAP</span>
            <h1 className="khu-gioi-thieu__tieu-de">
              Mang <em>màu xanh</em> vào không gian sống của bạn
            </h1>
            <p className="khu-gioi-thieu__mo-ta">
              Từ cây để bàn nhỏ xinh đến cây phong thủy hợp mệnh, Xanh SM
              tuyển chọn và giao tận nơi trong ngày — cây khỏe, giá hợp lý.
            </p>
            <div className="khu-gioi-thieu__hanh-dong">
              <a href="#san-pham" className="nut-chinh">Khám phá cây cảnh</a>
              <button type="button" className="nut-phu" onClick={() => datHienCamKet(true)}>
                Vì sao chọn chúng tôi
              </button>
            </div>

            <div className="khu-gioi-thieu__so-lieu">
              <div>
                <div className="so-lieu__so">120+</div>
                <div className="so-lieu__nhan">Loại cây cảnh</div>
              </div>
              <div>
                <div className="so-lieu__so">15.000+</div>
                <div className="so-lieu__nhan">Khách hàng hài lòng</div>
              </div>
              <div>
                <div className="so-lieu__so">4.8/5</div>
                <div className="so-lieu__nhan">Đánh giá trung bình</div>
              </div>
            </div>
          </div>

          <div className="khu-gioi-thieu__anh">
            <div className="khu-gioi-thieu__the-noi">
              <div className="the-noi__cham">🚚</div>
              <div>
                <div className="the-noi__tieu-de">Giao trong 2 giờ</div>
                <div className="the-noi__phu">Nội thành Hà Nội & TP.HCM</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="khu-danh-muc khung" id="san-pham">
        <div className="tieu-de-khu">
          <div>
            <h2>Cây cảnh nổi bật</h2>
            <p>Chọn theo nhu cầu không gian và mức độ chăm sóc bạn mong muốn</p>
          </div>
        </div>

        <div className="hang-danh-muc">
          {danhMucCay.map((muc) => (
            <button
              key={muc.id}
              className={`nut-danh-muc ${danhMucDangChon === muc.id ? 'nut-danh-muc--dang-chon' : ''}`}
              onClick={() => datDanhMucDangChon(muc.id)}
            >
              {muc.ten}
            </button>
          ))}
        </div>

        <div className="luoi-san-pham">
          {cayHienThi.map((cay) => (
            <TheCay key={cay.id} cay={cay} />
          ))}
        </div>
      </section>

      {hienCamKet && (
        <PopUpThongTin
          tieuDe="Vì sao chọn Xanh SM"
          moTa="Cam kết chất lượng từ vườn ươm đến tận nhà bạn"
          onDong={() => datHienCamKet(false)}
        >
          <div className="luoi-cam-ket">
            {camKet.map((muc) => (
              <div className="the-cam-ket" key={muc.so}>
                <div className="the-cam-ket__so">{muc.so}</div>
                <h3 className="the-cam-ket__tieu-de">{muc.tieuDe}</h3>
                <p className="the-cam-ket__mo-ta">{muc.moTa}</p>
              </div>
            ))}
          </div>
        </PopUpThongTin>
      )}

      <section className="khu-dang-ky">
        <div className="khung">
          <div className="hop-dang-ky">
            <div>
              <h2 className="hop-dang-ky__tieu-de">
                Nhận mẹo chăm cây & ưu đãi mỗi tuần
              </h2>
              <p className="hop-dang-ky__mo-ta">
                Đăng ký để nhận hướng dẫn chăm sóc cây và mã giảm giá dành riêng cho bạn.
              </p>
            </div>
            <form
              className="form-dang-ky"
              onSubmit={(sukKien) => sukKien.preventDefault()}
            >
              <input type="email" placeholder="Nhập email của bạn" required />
              <button type="submit" className="nut-chinh">Đăng ký</button>
            </form>
          </div>
        </div>
      </section>
    </>
  )
}
