import { useState } from 'react'
import { Link } from 'react-router-dom'
import { dungSanPham } from '../ngCanhSanPham.jsx'
import { dungNguoiDung } from '../ngCanhNguoiDung.jsx'
import { dinhDangTien } from '../tienIch/dinhDang.js'

export default function QuanTri() {
  const { danhSachCay, xoaCay } = dungSanPham()
  const { nguoiDungHienTai } = dungNguoiDung()
  const [dangXoaId, datDangXoaId] = useState(null)

  const xuLyXoa = (cay) => {
    if (dangXoaId === cay.id) {
      xoaCay(cay.id)
      datDangXoaId(null)
    } else {
      datDangXoaId(cay.id)
    }
  }

  return (
    <div className="khung trang-quan-tri">
      <div className="tieu-de-khu">
        <div>
          <h2>Quản trị cây cảnh</h2>
          <p>
            Xin chào {nguoiDungHienTai?.hoTen} · {danhSachCay.length} sản phẩm trong hệ thống
          </p>
        </div>
        <Link to="/quan-tri/them" className="nut-chinh">
          + Thêm cây mới
        </Link>
      </div>

      <div className="bang-quan-tri-boc">
        <table className="bang-quan-tri">
          <thead>
            <tr>
              <th>Ảnh</th>
              <th>Tên cây</th>
              <th>Danh mục</th>
              <th>Giá</th>
              <th>Nổi bật</th>
              <th>Hành động</th>
            </tr>
          </thead>
          <tbody>
            {danhSachCay.map((cay) => (
              <tr key={cay.id}>
                <td>
                  <div
                    className="bang-quan-tri__anh"
                    style={
                      cay.anhUrl
                        ? { backgroundImage: `url(${cay.anhUrl})`, backgroundSize: 'cover', backgroundPosition: 'center' }
                        : { background: `linear-gradient(155deg, ${cay.anhMauSac}, #10321d)` }
                    }
                  />
                </td>
                <td>
                  <strong>{cay.ten}</strong>
                  <div className="bang-quan-tri__phu">{cay.tenKhoaHoc}</div>
                </td>
                <td>{cay.danhMuc}</td>
                <td>{dinhDangTien(cay.gia)}</td>
                <td>{cay.noiBat ? '✅' : '—'}</td>
                <td>
                  <div className="bang-quan-tri__hanh-dong">
                    <Link to={`/quan-tri/sua/${cay.id}`} className="nut-nho">
                      Sửa
                    </Link>
                    <button
                      className={`nut-nho ${dangXoaId === cay.id ? 'nut-nho--nguy-hiem' : ''}`}
                      onClick={() => xuLyXoa(cay)}
                    >
                      {dangXoaId === cay.id ? 'Bấm lần nữa để xóa' : 'Xóa'}
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}
