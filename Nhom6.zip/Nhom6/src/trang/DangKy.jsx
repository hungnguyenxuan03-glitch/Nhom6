import { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { dungNguoiDung } from '../ngCanhNguoiDung.jsx'

export default function DangKy() {
  const { dangKy } = dungNguoiDung()
  const dieuHuong = useNavigate()

  const [hoTen, datHoTen] = useState('')
  const [tenDangNhap, datTenDangNhap] = useState('')
  const [matKhau, datMatKhau] = useState('')
  const [nhapLaiMatKhau, datNhapLaiMatKhau] = useState('')
  const [loi, datLoi] = useState('')

  const xuLySubmit = (sukKien) => {
    sukKien.preventDefault()
    datLoi('')

    if (tenDangNhap.trim().length < 3) {
      datLoi('Tên đăng nhập cần ít nhất 3 ký tự.')
      return
    }
    if (/\s/.test(tenDangNhap.trim())) {
      datLoi('Tên đăng nhập không được chứa khoảng trắng.')
      return
    }
    if (matKhau.length < 6) {
      datLoi('Mật khẩu cần ít nhất 6 ký tự.')
      return
    }
    if (matKhau !== nhapLaiMatKhau) {
      datLoi('Mật khẩu nhập lại không khớp.')
      return
    }

    const ketQua = dangKy({ hoTen: hoTen.trim(), tenDangNhap: tenDangNhap.trim(), matKhau })
    if (!ketQua.thanhCong) {
      datLoi(ketQua.thongBao)
      return
    }
    dieuHuong('/', { replace: true })
  }

  return (
    <div className="khung trang-xac-thuc">
      <div className="hop-xac-thuc">
        <h2>Tạo tài khoản</h2>
        <p className="hop-xac-thuc__mo-ta">
          Đăng ký miễn phí để mua cây và lưu lại đơn hàng của bạn.
        </p>

        <form onSubmit={xuLySubmit} className="form-xac-thuc">
          <label>
            Họ và tên
            <input
              type="text"
              value={hoTen}
              onChange={(e) => datHoTen(e.target.value)}
              placeholder="Nguyễn Văn A"
              required
            />
          </label>

          <label>
            Tên đăng nhập
            <input
              type="text"
              value={tenDangNhap}
              onChange={(e) => datTenDangNhap(e.target.value)}
              placeholder="vidu: nguyenvana"
              autoComplete="username"
              required
            />
          </label>

          <label>
            Mật khẩu
            <input
              type="password"
              value={matKhau}
              onChange={(e) => datMatKhau(e.target.value)}
              placeholder="Ít nhất 6 ký tự"
              autoComplete="new-password"
              required
            />
          </label>

          <label>
            Nhập lại mật khẩu
            <input
              type="password"
              value={nhapLaiMatKhau}
              onChange={(e) => datNhapLaiMatKhau(e.target.value)}
              placeholder="••••••••"
              autoComplete="new-password"
              required
            />
          </label>

          {loi && <p className="thong-bao-loi">{loi}</p>}

          <button type="submit" className="nut-chinh" style={{ width: '100%' }}>
            Đăng ký
          </button>
        </form>

        <p className="hop-xac-thuc__chuyen">
          Đã có tài khoản? <Link to="/dang-nhap">Đăng nhập</Link>
        </p>
      </div>
    </div>
  )
}
