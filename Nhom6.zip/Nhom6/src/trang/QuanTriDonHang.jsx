import { dungDonHang, CAC_TRANG_THAI } from '../ngCanhDonHang.jsx'
import { dinhDangTien } from '../tienIch/dinhDang.js'

export default function QuanTriDonHang() {
  const { danhSachDonHang, capNhatTrangThai } = dungDonHang()

  return (
    <div className="khung trang-quan-tri">
      <div className="tieu-de-khu">
        <div>
          <h2>Danh sách đơn hàng</h2>
          <p>{danhSachDonHang.length} đơn hàng từ khách hàng</p>
        </div>
      </div>

      {danhSachDonHang.length === 0 ? (
        <div className="gio-hang-trong">
          <h2>Chưa có đơn hàng nào</h2>
          <p>Đơn hàng của khách sẽ hiện tại đây sau khi họ thanh toán.</p>
        </div>
      ) : (
        <div className="bang-quan-tri-boc">
          <table className="bang-quan-tri">
            <thead>
              <tr>
                <th>Mã đơn</th>
                <th>Khách hàng</th>
                <th>Ngày đặt</th>
                <th>Sản phẩm</th>
                <th>Tổng tiền</th>
                <th>Trạng thái</th>
              </tr>
            </thead>
            <tbody>
              {danhSachDonHang.map((donHang) => (
                <tr key={donHang.id}>
                  <td><strong>{donHang.maDon}</strong></td>
                  <td>
                    {donHang.hoTenNguoiDung}
                    <div className="bang-quan-tri__phu">@{donHang.tenDangNhapNguoiDung}</div>
                  </td>
                  <td>{new Date(donHang.ngayDat).toLocaleDateString('vi-VN')}</td>
                  <td>
                    {donHang.cacMuc.map((m) => `${m.ten} ×${m.soLuong}`).join(', ')}
                  </td>
                  <td>{dinhDangTien(donHang.tongCong)}</td>
                  <td>
                    <select
                      value={donHang.trangThai}
                      onChange={(e) => capNhatTrangThai(donHang.id, e.target.value)}
                      className={`chon-trang-thai chon-trang-thai--${donHang.trangThai}`}
                    >
                      {CAC_TRANG_THAI.map((tt) => (
                        <option key={tt.id} value={tt.id}>{tt.ten}</option>
                      ))}
                    </select>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  )
}
