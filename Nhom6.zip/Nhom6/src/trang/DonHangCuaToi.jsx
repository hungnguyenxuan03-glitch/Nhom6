import { Link } from 'react-router-dom'
import { dungNguoiDung } from '../ngCanhNguoiDung.jsx'
import { dungDonHang, CAC_TRANG_THAI } from '../ngCanhDonHang.jsx'
import { dinhDangTien } from '../tienIch/dinhDang.js'

export default function DonHangCuaToi() {
  const { nguoiDungHienTai } = dungNguoiDung()
  const { layDonHangTheoNguoiDung } = dungDonHang()

  const donHangCuaToi = layDonHangTheoNguoiDung(nguoiDungHienTai.tenDangNhap)

  if (donHangCuaToi.length === 0) {
    return (
      <div className="gio-hang-trong khung">
        <h2>Bạn chưa có đơn hàng nào</h2>
        <p>Hãy chọn vài chậu cây xanh để bắt đầu nhé.</p>
        <Link to="/san-pham" className="nut-chinh" style={{ display: 'inline-block', marginTop: 16 }}>
          Khám phá cây cảnh
        </Link>
      </div>
    )
  }

  return (
    <div className="khung trang-don-hang">
      <div className="tieu-de-khu">
        <div>
          <h2>Đơn hàng của tôi</h2>
          <p>{donHangCuaToi.length} đơn hàng đã đặt</p>
        </div>
      </div>

      <div className="danh-sach-the-don">
        {donHangCuaToi.map((donHang) => {
          const tenTrangThai = CAC_TRANG_THAI.find((t) => t.id === donHang.trangThai)?.ten
          return (
            <div className="the-don-hang" key={donHang.id}>
              <div className="the-don-hang__dau">
                <div>
                  <strong>{donHang.maDon}</strong>
                  <div className="the-don-hang__ngay">
                    {new Date(donHang.ngayDat).toLocaleString('vi-VN')}
                  </div>
                </div>
                <span className={`the-trang-thai the-trang-thai--${donHang.trangThai}`}>
                  {tenTrangThai}
                </span>
              </div>

              <div className="danh-sach-don-thu-nho">
                {donHang.cacMuc.map((muc) => (
                  <div className="dong-don-thu-nho" key={muc.cayId}>
                    <span>{muc.ten} × {muc.soLuong}</span>
                    <span>{dinhDangTien(muc.gia * muc.soLuong)}</span>
                  </div>
                ))}
              </div>

              <div className="the-don-hang__tong">
                <span>Tổng cộng</span>
                <strong>{dinhDangTien(donHang.tongCong)}</strong>
              </div>
            </div>
          )
        })}
      </div>
    </div>
  )
}
