import { Route, Routes } from 'react-router-dom'
import ThanhDieuHuong from './components/ThanhDieuHuong.jsx'
import ChanTrang from './components/ChanTrang.jsx'
import RouteBaoVe from './components/RouteBaoVe.jsx'
import TrangChu from './trang/TrangChu.jsx'
import TrangSanPham from './trang/TrangSanPham.jsx'
import TrangChiTiet from './trang/TrangChiTiet.jsx'
import TrangGioHang from './trang/TrangGioHang.jsx'
import DangNhap from './trang/DangNhap.jsx'
import DangKy from './trang/DangKy.jsx'
import XacNhanDonHang from './trang/XacNhanDonHang.jsx'
import DonHangCuaToi from './trang/DonHangCuaToi.jsx'
import QuanTri from './trang/QuanTri.jsx'
import QuanTriThemSua from './trang/QuanTriThemSua.jsx'
import QuanTriDonHang from './trang/QuanTriDonHang.jsx'
import { NhaCungCapGioHang } from './ngCanhGioHang.jsx'
import { NhaCungCapNguoiDung } from './ngCanhNguoiDung.jsx'
import { NhaCungCapSanPham } from './ngCanhSanPham.jsx'
import { NhaCungCapDonHang } from './ngCanhDonHang.jsx'

export default function UngDung() {
  return (
    <NhaCungCapNguoiDung>
      <NhaCungCapSanPham>
        <NhaCungCapDonHang>
          <NhaCungCapGioHang>
            <ThanhDieuHuong />
            <main>
              <Routes>
                <Route path="/" element={<TrangChu />} />
                <Route path="/san-pham" element={<TrangSanPham />} />
                <Route path="/san-pham/:id" element={<TrangChiTiet />} />
                <Route path="/gio-hang" element={<TrangGioHang />} />
                <Route path="/dang-nhap" element={<DangNhap />} />
                <Route path="/dang-ky" element={<DangKy />} />

                <Route
                  path="/don-hang/:id"
                  element={
                    <RouteBaoVe>
                      <XacNhanDonHang />
                    </RouteBaoVe>
                  }
                />
                <Route
                  path="/don-hang"
                  element={
                    <RouteBaoVe>
                      <DonHangCuaToi />
                    </RouteBaoVe>
                  }
                />

                <Route
                  path="/quan-tri"
                  element={
                    <RouteBaoVe yeuCauAdmin>
                      <QuanTri />
                    </RouteBaoVe>
                  }
                />
                <Route
                  path="/quan-tri/them"
                  element={
                    <RouteBaoVe yeuCauAdmin>
                      <QuanTriThemSua />
                    </RouteBaoVe>
                  }
                />
                <Route
                  path="/quan-tri/sua/:id"
                  element={
                    <RouteBaoVe yeuCauAdmin>
                      <QuanTriThemSua />
                    </RouteBaoVe>
                  }
                />
                <Route
                  path="/quan-tri/don-hang"
                  element={
                    <RouteBaoVe yeuCauAdmin>
                      <QuanTriDonHang />
                    </RouteBaoVe>
                  }
                />
              </Routes>
            </main>
            <ChanTrang />
          </NhaCungCapGioHang>
        </NhaCungCapDonHang>
      </NhaCungCapSanPham>
    </NhaCungCapNguoiDung>
  )
}
